<?php

$con = mysqli_connect("localhost", "root", "adminohmza1", "noob-php") or die("ไม่สามารถเชื่อมต่อได้ครับ");
mysqli_set_charset($con,"utf8");

        
